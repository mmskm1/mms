import React, { useState } from 'react';
import { Star, ChevronDown, ShoppingCart, Heart } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: number;
  rating: number;
  image: string;
  brand: string;
  category: string;
}

const products: Product[] = [
  {
    id: 1,
    name: 'عطر ديور هوم انتنس - رجالي',
    price: 759,
    rating: 5,
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    brand: 'ديور',
    category: 'عطور رجالية'
  },
  {
    id: 2,
    name: 'عطر دولتشي آند غابانا كينغ - رجالي',
    price: 899,
    rating: 4,
    image: 'https://images.unsplash.com/photo-1587017539504-67cfbddac569?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    brand: 'دولتشي آند غابانا',
    category: 'عطور رجالية'
  },
  {
    id: 3,
    name: 'عطر شانيل بلو - رجالي',
    price: 699,
    rating: 5,
    image: 'https://images.unsplash.com/photo-1585386959984-a4155224a1ad?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    brand: 'شانيل',
    category: 'عطور رجالية'
  }
];

const ProductsPage = () => {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);

  const renderStars = (rating: number) => {
    return [...Array(5)].map((_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Hero Banner */}
      <div className="relative h-[300px] bg-black">
        <img
          src="https://images.unsplash.com/photo-1533603208986-24fd819e718a?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80"
          alt="عطور فاخرة"
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl font-bold text-white">عطور فاخرة</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="w-full md:w-1/4 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold mb-4">فئات المنتجات</h3>
              <div className="space-y-2">
                {['عطور رجالية', 'عطور نسائية', 'عطور شرقية', 'عطور فرنسية'].map(
                  (category) => (
                    <label key={category} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        className="form-checkbox"
                        checked={selectedCategories.includes(category)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedCategories([...selectedCategories, category]);
                          } else {
                            setSelectedCategories(
                              selectedCategories.filter((c) => c !== category)
                            );
                          }
                        }}
                      />
                      <span className="mr-2">{category}</span>
                    </label>
                  )
                )}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold mb-4">نطاق السعر</h3>
              <div className="space-y-4">
                <input
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[1]}
                  onChange={(e) =>
                    setPriceRange([priceRange[0], parseInt(e.target.value)])
                  }
                  className="w-full"
                />
                <div className="flex justify-between">
                  <span>{priceRange[0]} ريال</span>
                  <span>{priceRange[1]} ريال</span>
                </div>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="w-full md:w-3/4">
            <div className="mb-6 flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <span className="text-gray-600">24 منتج</span>
                <button className="flex items-center space-x-2 text-gray-600">
                  <span className="mr-2">الترتيب حسب</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 bg-gray-200 rounded">
                  <svg
                    className="h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </button>
                <button className="p-2 bg-gray-200 rounded">
                  <svg
                    className="h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 10h16M4 14h16M4 18h16"
                    />
                  </svg>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-lg shadow-md overflow-hidden group"
                >
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute top-4 left-4 space-y-2">
                      <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100 transition">
                        <Heart className="h-5 w-5 text-gray-600" />
                      </button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                    <div className="flex items-center mb-2">
                      {renderStars(product.rating)}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-blue-600">
                        {product.price} ريال
                      </span>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center space-x-2">
                        <ShoppingCart className="h-5 w-5" />
                        <span className="mr-2">أضف للسلة</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;