import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Twitter, Phone, User, Smartphone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-secondary/30 pt-16 pb-8">
      <div className="container">
        {/* Newsletter Subscription */}
        <div className="bg-secondary/20 rounded-xl p-8 mb-16">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 max-w-4xl mx-auto">
            <motion.h3 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-xl font-semibold whitespace-nowrap"
            >
              اشترك في النشرة البريدية الآن واحصل على خصومات رائعة
            </motion.h3>
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex w-full max-w-md"
            >
              <button className="bg-primary text-white px-6 py-2 rounded-l-lg hover:bg-primary/90 transition-colors whitespace-nowrap">
                اشترك الآن
              </button>
              <input
                type="email"
                placeholder="البريد الإلكتروني"
                className="w-full px-4 py-2 rounded-r-lg border border-gray-300 focus:outline-none focus:border-primary"
              />
            </motion.div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Logo and Certificates */}
          <div className="text-center md:text-right">
            <div className="text-3xl font-bold mb-4 text-primary">SELIA</div>
            <div className="flex justify-center md:justify-end gap-4">
              <div className="flex flex-col items-center">
                <img 
                  src="https://maroof.sa/assets/images/maroof-logo.png" 
                  alt="معروف"
                  className="h-10 w-auto mb-2"
                />
                <span className="text-sm">معروف</span>
              </div>
              <div className="flex flex-col items-center">
                <img 
                  src="https://zatca.gov.sa/ar/E-Invoicing/PublishingImages/zatca-logo.png" 
                  alt="ضريبة القيمة المضافة"
                  className="h-10 w-auto mb-2"
                />
                <span className="text-sm">ضريبة القيمة المضافة</span>
              </div>
            </div>
          </div>

          {/* Important Links */}
          <div className="text-center md:text-right">
            <h4 className="font-semibold mb-4">روابط مهمة</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-primary">المدونة</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">سياسة الاستبدال</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">سياسة الخصوصية</a></li>
            </ul>
          </div>

          {/* Mobile App */}
          <div className="text-center">
            <h4 className="font-semibold mb-4">تحميل تطبيق الجوال</h4>
            <div className="flex justify-center gap-4">
              <div className="h-[40px] flex items-center">
                <img 
                  src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" 
                  alt="Google Play"
                  className="h-full w-auto cursor-pointer hover:opacity-90 transition-opacity"
                />
              </div>
              <div className="h-[40px] flex items-center">
                <img 
                  src="https://developer.apple.com/app-store/marketing/guidelines/images/badge-example-preferred.png" 
                  alt="App Store"
                  className="h-full w-auto cursor-pointer hover:opacity-90 transition-opacity"
                />
              </div>
            </div>
            <div className="mt-4">
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center"
              >
                <img 
                  src="https://maroof.sa/assets/images/maroof-qr.png" 
                  alt="موثق لدى منصة الأعمال"
                  className="h-16 w-auto mb-2"
                />
                <span className="text-sm text-gray-600">موثق لدى منصة الأعمال</span>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Social Media and Contact Bar */}
        <div className="border-t border-gray-200 py-6">
          <div className="flex flex-wrap justify-center gap-6">
            <motion.a 
              href="#" 
              className="text-gray-600 hover:text-primary transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              <Facebook className="h-6 w-6" />
            </motion.a>
            <motion.a 
              href="#" 
              className="text-gray-600 hover:text-primary transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              <Instagram className="h-6 w-6" />
            </motion.a>
            <motion.a 
              href="#" 
              className="text-gray-600 hover:text-primary transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              <Twitter className="h-6 w-6" />
            </motion.a>
            <div className="w-full md:w-auto flex justify-center gap-6 mt-4 md:mt-0">
              <motion.button 
                className="text-gray-600 hover:text-primary transition-colors"
                whileHover={{ scale: 1.1 }}
              >
                <Phone className="h-6 w-6" />
              </motion.button>
              <motion.button 
                className="text-gray-600 hover:text-primary transition-colors"
                whileHover={{ scale: 1.1 }}
              >
                <User className="h-6 w-6" />
              </motion.button>
              <motion.button 
                className="text-gray-600 hover:text-primary transition-colors"
                whileHover={{ scale: 1.1 }}
              >
                <Smartphone className="h-6 w-6" />
              </motion.button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-200 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-gray-600 text-sm text-center md:text-right order-2 md:order-1">
              الحقوق محفوظة © سيليا 2024 | سجل تجاري 1234567890
            </p>
            
            <motion.div 
              className="flex items-center gap-4 order-1 md:order-2"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <img src="https://www.visa.com/images/visa-logo.png" alt="Visa" className="h-8 w-auto" />
              <img src="https://www.mada.com.sa/sites/default/files/mada-logo.png" alt="Mada" className="h-8 w-auto" />
              <img src="https://www.bankrate.com/2022/09/30113423/What-is-a-bank.png" alt="Bank Transfer" className="h-8 w-auto" />
              <img src="https://developer.apple.com/apple-pay/images/apple-pay-mark.svg" alt="Apple Pay" className="h-8 w-auto" />
              <img src="https://www.stc.com.sa/content/dam/stc/images/stcpay-logo.png" alt="STC Pay" className="h-8 w-auto" />
              <img src="https://tamara.co/assets/tamara-logo.svg" alt="Tamara" className="h-8 w-auto" />
            </motion.div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;