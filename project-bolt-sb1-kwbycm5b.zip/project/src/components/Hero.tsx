import React from 'react';
import { motion } from 'framer-motion';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

const Hero = () => {
  const slides = [
    {
      id: 1,
      title: 'عروضنا مستمرة',
      subtitle: 'بمناسبة يوم التأسيس',
      image: 'https://images.unsplash.com/photo-1621184455862-c163dfb30e0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80',
      bgColor: 'bg-secondary'
    },
    {
      id: 2,
      title: 'تشكيلة جديدة',
      subtitle: 'أحدث العطور العالمية',
      image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80',
      bgColor: 'bg-gray-100'
    }
  ];

  return (
    <section className="relative">
      <Swiper
        modules={[Autoplay, Pagination, EffectFade]}
        autoplay={{ delay: 5000 }}
        pagination={{ clickable: true }}
        effect="fade"
        loop={true}
        className="h-[600px]"
      >
        {slides.map((slide) => (
          <SwiperSlide key={slide.id}>
            <div className={`relative h-full ${slide.bgColor}`}>
              <div className="container h-full flex items-center">
                <div className="w-full lg:w-1/2 space-y-6 z-10">
                  <motion.h1 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-5xl lg:text-6xl font-bold text-right"
                  >
                    {slide.title}
                  </motion.h1>
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-xl text-right text-gray-600"
                  >
                    {slide.subtitle}
                  </motion.p>
                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    whileHover={{ scale: 1.05 }}
                    className="btn-primary block mr-auto"
                  >
                    تسوق الآن
                  </motion.button>
                </div>
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8 }}
                  className="absolute left-0 top-0 w-full lg:w-1/2 h-full"
                >
                  <div className="relative h-full">
                    <div className="absolute inset-0 bg-gradient-to-l from-transparent to-secondary/50 lg:to-secondary z-10" />
                    <img 
                      src={slide.image}
                      alt={slide.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </motion.div>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
};

export default Hero;