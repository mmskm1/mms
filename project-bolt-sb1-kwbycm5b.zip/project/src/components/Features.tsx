import React from 'react';
import { motion } from 'framer-motion';
import { Headphones, Gift, RefreshCw, Truck, Star } from 'lucide-react';

const features = [
  {
    id: 1,
    icon: <Headphones className="w-8 h-8" />,
    title: 'دعم فني على مدار الساعة',
    description: 'بفضل الدعم الفني الفوري، ستستمتع بتجربة تسوق مميزة وفريدة من نوعها'
  },
  {
    id: 2,
    icon: <Gift className="w-8 h-8" />,
    title: 'برامج الولاء',
    description: 'كعميل في متجرنا، ستستفيد من برامج الولاء والتخفيضات الحصرية'
  },
  {
    id: 3,
    icon: <RefreshCw className="w-8 h-8" />,
    title: 'ضمان استعادة الأموال',
    description: 'نحن ملتزمون بتقديم أعلى مستوى من الجودة والرضا لعملائنا'
  },
  {
    id: 4,
    icon: <Truck className="w-8 h-8" />,
    title: 'توصيل سريع ومجاني',
    description: 'نقدم خدمة توصيل سريعة ومجانية لجميع عملائنا'
  }
];

const testimonials = [
  {
    id: 1,
    name: 'Demo Account',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
    comment: 'متجر رائع لتنوع المنتجات وجودة المبيعات',
    rating: 5
  },
  {
    id: 2,
    name: 'Ahmed Testing123456',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=2',
    comment: 'تجربة جيدة ومتجر ممتاز وتجاوب سريع مع ما شاء الله المصداقية وقوة',
    rating: 5
  },
  {
    id: 3,
    name: 'Demo Account',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=3',
    comment: 'أنصح به وبشدة شكراً سيليا',
    rating: 5
  },
  {
    id: 4,
    name: 'Sarah',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=4',
    comment: 'خدمة عملاء ممتازة وتوصيل سريع، أفضل متجر تعاملت معه',
    rating: 5
  }
];

const paymentMethods = [
  { id: 1, name: 'Apple Pay', image: '/apple-pay.png' },
  { id: 2, name: 'Mada', image: '/mada.png' },
  { id: 3, name: 'Bank Transfer', image: '/bank.png' },
  { id: 4, name: 'Visa', image: '/visa.png' },
  { id: 5, name: 'STC Pay', image: '/stc-pay.png' },
  { id: 6, name: 'Tamara', image: '/tamara.png' }
];

const Features = () => {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section className="py-16">
      <div className="container">
        {/* Payment Methods */}
        <div className="bg-white rounded-2xl p-8 mb-16 text-center">
          <div className="flex flex-wrap justify-center items-center gap-8">
            {paymentMethods.map((method) => (
              <motion.img
                key={method.id}
                src={method.image}
                alt={method.name}
                className="h-8 object-contain"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              />
            ))}
          </div>
          <p className="text-gray-600 mt-4">جميع طرق الدفع آمنة 100%</p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              whileHover={{ 
                scale: 1.05,
                transition: { 
                  type: "spring",
                  stiffness: 300
                }
              }}
              className="bg-white p-6 rounded-xl text-center cursor-pointer group"
            >
              <motion.div 
                className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-gray-100 rounded-full"
                whileHover={{ 
                  rotate: 360,
                  backgroundColor: "#E6D5C9",
                  transition: { duration: 0.5 }
                }}
              >
                {feature.icon}
              </motion.div>
              <motion.h3 
                className="text-lg font-semibold mb-2"
                whileHover={{ scale: 1.1 }}
              >
                {feature.title}
              </motion.h3>
              <p className="text-gray-600 text-sm group-hover:text-primary transition-colors">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Testimonials */}
        <div>
          <div className="flex flex-col items-center justify-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-2xl font-bold text-center mb-4"
            >
              آراء العملاء
            </motion.h2>
            <div className="flex items-center gap-4 w-full max-w-[200px]">
              <div className="flex-1 h-[1px] bg-gray-300"></div>
              <div className="w-2 h-2 rounded-full bg-gray-300"></div>
              <div className="flex-1 h-[1px] bg-gray-300"></div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.id}
                initial={{ opacity: 0, x: 100 }}
                whileInView={{ 
                  opacity: 1, 
                  x: 0,
                  transition: {
                    type: "spring",
                    stiffness: 100,
                    damping: 20,
                    delay: index * 0.1
                  }
                }}
                viewport={{ once: true }}
                whileHover={{
                  scale: 1.02,
                  x: -10,
                  transition: {
                    type: "spring",
                    stiffness: 300,
                    damping: 20
                  }
                }}
                className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
              >
                <motion.p 
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 + 0.3 }}
                  className="text-gray-600 mb-4"
                >
                  {testimonial.comment}
                </motion.p>
                <motion.div 
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 + 0.4 }}
                  className="flex justify-between items-center"
                >
                  <div className="flex items-center gap-2">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-10 h-10 rounded-full"
                    />
                    <span className="font-medium">{testimonial.name}</span>
                  </div>
                  <div className="flex">{renderStars(testimonial.rating)}</div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;