import React from 'react';
import { motion } from 'framer-motion';

const categories = [
  {
    id: 1,
    name: 'عطور',
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'لمسة من الأناقة'
  },
  {
    id: 2,
    name: 'عناية بالبشرة',
    image: 'https://images.unsplash.com/photo-1505944270255-72b8c68c6a70?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'جمال طبيعي'
  },
  {
    id: 3,
    name: 'أزياء نسائية',
    image: 'https://images.unsplash.com/photo-1589810635657-232948472d98?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'أناقة لا تنتهي'
  },
  {
    id: 4,
    name: 'أزياء رجالية',
    image: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'تألق بأسلوبك'
  }
];

const Categories = () => {
  return (
    <section className="py-16">
      <div className="container">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">تسوق حسب الفئة</h2>
          <p className="text-gray-600">اكتشف مجموعتنا المميزة من المنتجات</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative rounded-2xl overflow-hidden aspect-[4/5]">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col items-center justify-end p-6 text-white">
                  <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                  <p className="text-sm text-gray-200 mb-4">{category.description}</p>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    className="bg-white text-primary px-6 py-2 rounded-lg text-sm font-medium"
                  >
                    تسوق الآن
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;