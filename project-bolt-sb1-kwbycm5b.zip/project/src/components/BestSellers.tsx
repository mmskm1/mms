import React from 'react';
import { motion } from 'framer-motion';
import { Star, ShoppingCart } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'ديور - اوم انتنس - ١٠٠ مل',
    category: 'العطر:رجالي',
    price: 759,
    rating: 5,
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    name: 'عطر ذا ون من دولتشي آند غابانا للرجال معطر - او دي تواليت',
    category: 'العطر:نسائي',
    price: 319.7,
    rating: 5,
    image: 'https://images.unsplash.com/photo-1587017539504-67cfbddac569?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];

const BestSellers = () => {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section className="py-16 bg-black/95">
      <div className="container">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-secondary mb-4">
            <span className="ml-2">✨</span>
            الأكثر مبيعاً
            <span className="mr-2">✨</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg overflow-hidden group"
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/2">
                  <div className="relative h-[300px]">
                    <img 
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                </div>
                <div className="md:w-1/2 p-6 flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-right">{product.name}</h3>
                    <p className="text-gray-600 text-sm mb-4 text-right">{product.category}</p>
                    <div className="flex justify-end mb-4">
                      {renderStars(product.rating)}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      className="bg-primary text-white px-4 py-2 rounded-lg flex items-center gap-2"
                    >
                      <ShoppingCart className="h-5 w-5" />
                      <span>أضف للسلة</span>
                    </motion.button>
                    <span className="text-xl font-bold text-primary">
                      {product.price} ر.س
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;