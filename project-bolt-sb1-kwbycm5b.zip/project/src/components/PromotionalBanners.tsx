import React, { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, EffectFade } from 'swiper/modules';
import { motion } from 'framer-motion';
import { Pause, Play } from 'lucide-react';
import 'swiper/css';
import 'swiper/css/effect-fade';

const banners = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80',
    title: 'خصم 25%',
    code: 'SELIA25',
    description: 'على جميع العطور الفاخرة'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80',
    title: 'خصم 40%',
    code: 'SUMMER40',
    description: 'على مجموعة الصيف الجديدة'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80',
    title: 'خصم 30%',
    code: 'BEAUTY30',
    description: 'على منتجات العناية بالبشرة'
  }
];

const PromotionalBanner = ({ data, autoplay = true, height = 'h-[400px]' }) => {
  const [isPlaying, setIsPlaying] = useState(autoplay);

  return (
    <div className={`relative ${height} rounded-2xl overflow-hidden group`}>
      <Swiper
        modules={[Autoplay, EffectFade]}
        effect="fade"
        autoplay={
          isPlaying
            ? {
                delay: 3000,
                disableOnInteraction: false,
              }
            : false
        }
        loop={true}
        className="w-full h-full"
      >
        {data.map((banner) => (
          <SwiperSlide key={banner.id}>
            <div className="relative w-full h-full">
              <div className="absolute inset-0 bg-black/40 z-10" />
              <img
                src={banner.image}
                alt={banner.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-white text-center p-6">
                <motion.h3 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  className="text-4xl font-bold mb-4"
                >
                  {banner.title}
                </motion.h3>
                <motion.div 
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  className="bg-white/20 backdrop-blur-sm px-6 py-3 rounded-lg mb-4"
                >
                  <span className="text-2xl font-bold">{banner.code}</span>
                </motion.div>
                <motion.p 
                  initial={{ opacity: 0, y: -20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  className="text-lg"
                >
                  {banner.description}
                </motion.p>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      <button
        onClick={() => setIsPlaying(!isPlaying)}
        className="absolute bottom-4 left-4 z-30 bg-white/20 backdrop-blur-sm p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
      >
        {isPlaying ? (
          <Pause className="h-5 w-5 text-white" />
        ) : (
          <Play className="h-5 w-5 text-white" />
        )}
      </button>
    </div>
  );
};

const PromotionalBanners = () => {
  return (
    <section className="py-16 bg-gray-100">
      <div className="container space-y-8">
        {/* Main Banner */}
        <PromotionalBanner data={banners} />

        {/* Secondary Banners */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <PromotionalBanner 
            data={[banners[1], banners[2]]} 
            height="h-[200px]"
            autoplay={false}
          />
          <PromotionalBanner 
            data={[banners[0], banners[2]]} 
            height="h-[200px]"
            autoplay={false}
          />
        </div>
      </div>
    </section>
  );
};

export default PromotionalBanners;