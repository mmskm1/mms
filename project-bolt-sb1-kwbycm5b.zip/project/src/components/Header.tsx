import React from 'react';
import { Moon, Search, ShoppingCart, User } from 'lucide-react';
import { motion } from 'framer-motion';

const Header = () => {
  return (
    <header className="w-full bg-white">
      {/* Top Banner */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-primary text-white py-2 text-center text-sm border-b border-gray-800"
      >
        <span className="inline-flex items-center">
          <span className="ml-2">✨</span>
          خصم خاص لفترة محدودة جداً بمناسبة يوم التأسيس
          <span className="mr-2">✨</span>
        </span>
      </motion.div>

      {/* Secondary Header */}
      <div className="bg-secondary/30 py-2">
        <div className="container flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <a href="tel:920011112" className="hover:text-primary">920011112</a>
            <a href="mailto:info@selia.sa" className="hover:text-primary">info@selia.sa</a>
          </div>
          <div className="flex items-center gap-4">
            <button className="hover:text-primary">سياسة الخصوصية</button>
            <button className="hover:text-primary">سياسة الاستبدال</button>
            <select className="bg-transparent hover:text-primary cursor-pointer">
              <option value="SAR">ر.س</option>
              <option value="USD">USD</option>
            </select>
            <select className="bg-transparent hover:text-primary cursor-pointer">
              <option value="ar">العربية</option>
              <option value="en">English</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-2xl font-bold"
          >
            SELIA
          </motion.div>

          {/* Navigation */}
          <nav className="hidden lg:flex items-center space-x-8 space-x-reverse">
            {[
              'الموضة',
              'نسائي',
              'رجالي',
              'أطفال',
              'منتجات طبية',
              'عطور',
              'الإلكترونيات',
              'تخفيضات'
            ].map((item) => (
              <motion.a
                key={item}
                href="#"
                className="nav-link"
                whileHover={{ scale: 1.05 }}
              >
                {item}
              </motion.a>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-6">
            <motion.button whileHover={{ scale: 1.1 }}>
              <Moon className="h-5 w-5" />
            </motion.button>
            <motion.button whileHover={{ scale: 1.1 }}>
              <Search className="h-5 w-5" />
            </motion.button>
            <motion.button whileHover={{ scale: 1.1 }}>
              <User className="h-5 w-5" />
            </motion.button>
            <motion.button whileHover={{ scale: 1.1 }} className="relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                2
              </span>
            </motion.button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;