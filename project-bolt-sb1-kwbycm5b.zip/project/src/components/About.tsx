import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';

const About = () => {
  return (
    <section className="py-16 bg-black/95 text-white">
      <div className="container">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2"
          >
            <img 
              src="https://images.unsplash.com/photo-1600950207944-0d63e8edbc3f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80"
              alt="متجر سيليا"
              className="rounded-2xl w-full h-[400px] object-cover"
            />
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2 text-right"
          >
            <h2 className="text-secondary/90 mb-2">من نحن؟</h2>
            <h3 className="text-3xl font-bold mb-6 text-secondary">قصة متجر سيليا</h3>
            <p className="text-gray-300 leading-relaxed mb-8">
              متجر سيليا هو مكان سحري يفتح أمامك أبواب عالم الموضة والأناقة بنقرة واحدة. يتميز هذا المتجر بواجهة مستخدم مميزة وتصميم منظور حيث يسهل عليك تصفح مجموعة واسعة من الملابس والإكسسوارات بكل يسر وسلاسة. تتميز تجربة التسوق عبر متجرنا بخدمة عملاء استثنائية، حيث يقدم الفريق الدعم اللازم للمساعدة في اختيار القطع المناسبة والإجابة على استفساراتك بفعالية.
            </p>
            <motion.button
              whileHover={{ x: 10 }}
              className="inline-flex items-center gap-2 text-secondary hover:text-secondary/80 transition-colors"
            >
              اقرأ المزيد
              <ArrowLeft className="h-4 w-4" />
            </motion.button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;